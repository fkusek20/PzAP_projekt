
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import sqlite3
from flask import Flask, jsonify

# Loading the datasets
df_transactions = pd.read_csv('transakcije.csv')
df_generated = pd.read_json('franco.json')

# Određujemo veličinu uzorka za pranje novca i ne pranje novca
laundering_sample_size = 100  # Želimo 100 transakcija pranja novca
non_laundering_sample_size = 400  # i 400 transakcija koje nisu pranje novca

# Filtriranje transakcija koje su i nisu pranje novca
laundering_transactions = df_transactions[df_transactions['Is_laundering'] == 1]
non_laundering_transactions = df_transactions[df_transactions['Is_laundering'] == 0]

# Uzorkovanje transakcija pranja novca
laundering_sample = laundering_transactions.sample(n=laundering_sample_size, random_state=42)

# Uzorkovanje transakcija koje nisu pranje novca
non_laundering_sample = non_laundering_transactions.sample(n=non_laundering_sample_size, random_state=42)

# Spajamo uzorke u jedan DataFrame
df_sample = pd.concat([laundering_sample, non_laundering_sample]).sample(frac=1, random_state=42)  # Promiješamo redove

# Sada kombiniramo uzorak s generiranim podacima
df_combined = pd.concat([df_sample.reset_index(drop=True), df_generated], axis=1)



# One-hot encoding categorical variables
df_combined = pd.get_dummies(df_combined, columns=['Payment_type', 'Sender_bank_location', 'Receiver_bank_location'])

# Identifying non-numeric columns
non_numeric_columns = df_combined.select_dtypes(exclude=[np.number]).columns
print("Non-numeric columns:", non_numeric_columns)

# Drop non-numeric columns for correlation analysis
df_combined.drop(non_numeric_columns, axis=1, inplace=True)

# Handle missing values
df_combined.fillna(df_combined.mean(), inplace=True)

# Convert all columns to numeric
for col in df_combined.columns:
    df_combined[col] = pd.to_numeric(df_combined[col], errors='coerce')

# Correlation analysis
print(df_combined.corr()['Is_laundering'].sort_values())

# Normalizing the 'Amount' column for visualization
df_combined['Amount'] = (df_combined['Amount'] - df_combined['Amount'].min()) / (df_combined['Amount'].max() - df_combined['Amount'].min())

grouped_data = df_combined.groupby('Is_laundering')['Amount'].sum().reset_index()

# Preimenovanje za bolje razumijevanje na grafu
grouped_data['Is_laundering'] = grouped_data['Is_laundering'].map({0: 'Uobičajene', 1: 'Sumnjive'})
numerical_columns = df_combined.select_dtypes(include=[np.number]).columns
sns.pairplot(df_combined[numerical_columns])
plt.show()
# Vizualizacija usporedbe ukupnih iznosa za uobičajene i sumnjive transakcije
sns.barplot(x='Is_laundering', y='Amount', data=grouped_data)
plt.title('Usporedba ukupnih iznosa sumnjivih i uobičajenih transakcija')
plt.ylabel('Ukupan iznos transakcija')
plt.xlabel('Vrsta transakcije')
plt.show()

# Basic statistics for 'Amount'
print(df_combined['Amount'].describe())
# [Ostatak vašeg koda ostaje isti do dijela analize podataka]



# Saving DataFrame to a SQLite database
conn = sqlite3.connect('transakcije.db')
df_combined.to_sql('transakcije', conn, if_exists='replace', index=False)
conn.close()


# Flask application setup
app = Flask(__name__)

def get_db_connection():
    conn = sqlite3.connect('transakcije.db')
    conn.row_factory = sqlite3.Row
    return conn




@app.route('/transakcije', methods=['GET'])
def get_transakcije():
    conn = sqlite3.connect('transakcije.db')
    conn.row_factory = sqlite3.Row
    cur = conn.cursor()
    cur.execute("SELECT * FROM transakcije")
    transakcije_rows = cur.fetchall()
    conn.close()
    return jsonify([dict(row) for row in transakcije_rows])



if __name__ == '__main__':
    app.run(debug=True)